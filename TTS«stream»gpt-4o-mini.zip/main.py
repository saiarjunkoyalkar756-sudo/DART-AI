# Copyright 2026 Mr Dark
# Project: DarkAI
# Author: t.me/sii_3
# Licensed under Apache License 2.0



dark='t.me/sii_3'
источник='вебсайт: dark.ps'
версия='Выпустобщено в @2025 - обновлено в @2026'


П="coral" # VOICE_ID
Л="Speak in a warm, natural, and expressive female voice. Be conversational and clear, with a friendly tone similar to a helpful assistant. Use natural pacing, slight pauses when needed, and avoid sounding robotic or overly dramatic." # INSTRUCTIONS


_F='accept'
_E='content-type'
_D='user-agent'
_C='application/json'
_B=None
_A=True
import requests,json,random,uuid,datetime,os,time,sys,hashlib,types,re
def ok(text,delay=.03):
	for A in text:print(A,end='',flush=_A);time.sleep(delay)
	print()
class ps:
	кк=_B;ии=0;msg_count=0;пп=''.join(random.choices('0123456789abcdef',k=16));хх=str(uuid.uuid4())+'R';тт=f"{__import__("secrets").token_hex(2)}.mp3"
	def dark(B):
		A=requests.post('https://api.chatboxapp.ai/auth/v2/users',headers={_D:'ChatBox/1.82.3 (Windows_NT 10.0.19045; x64)',_E:_C,_F:_C,'accept-encoding':'gzip, deflate, br','connection':'keep-alive'},params={'deviceId':ps.пп,'appName':'ChatBox'},json={'strategy':'windowsV1'})
		if A.status_code==201:ps.кк=A.json().get('accessToken');ps.ии=0;return _A
		return False
	def sii_3(E,го):
		if not ps.кк and not E.dark():ok('[-] Auth fail');return
		F={'authority':'api.florate.io',_F:'audio/mpeg, application/json','authorization':f"Bearer {ps.кк}",_E:_C,'origin':'https://app.chatbox.ai','referer':'https://app.chatbox.ai/',_D:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36','accept-language':'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7','sec-ch-ua':'"Not A(Brand";v="99", "Google Chrome";v="132", "Chromium";v="132"','sec-ch-ua-mobile':'?0','sec-ch-ua-platform':'"Windows"','x-date':datetime.datetime.now(datetime.timezone.utc).strftime('%a, %d %b %Y %H:%M:%S GMT')};G={'model':'gpt-4o-mini-tts','prompt':го,'voice':П,'instructions':Л}
		try:
			H=time.time();B=requests.post('https://api.florate.io/text-to-speech',headers=F,json=G,stream=_A)
			if B.status_code!=200:ok(f"- {B.status_code}");ok(B.text);return
			A=_B;D=0;print();print(end='',flush=_A)
			with open(ps.тт,'wb')as I:
				for C in B.iter_content(chunk_size=1024):
					if C:
						if A is _B:A=time.time()
						I.write(C);D+=len(C);print('٭',end='',flush=_A)
			J=time.time();print();ok(f"\n[✓] Saved {ps.тт}");K=A-H if A else 0;L=J-A if A else 0;ok(f"[▣] Size: {D}");ok(f"[◷] TTFB: {K:.4f}s");ok(f"[⏱] Time: {L:.4f}s\n");os.system(f"mpv --no-video {ps.тт} > /dev/null 2>&1");ps.ии+=1;ps.msg_count+=1
		except Exception as M:ok(str(M))
def y():
 try:
  f=sys._getframe();c=f.f_code
  try:
   with open(c.co_filename,'r',encoding='utf-8')as fh:src=fh.read()
   lines=src.split(chr(10));st=c.co_firstlineno-1
   ind=len(lines[st])-len(lines[st].lstrip())
   en=st+1
   while en<len(lines)and(not lines[en].strip()or len(lines[en])-len(lines[en].lstrip())>ind):en+=1
   mysrc=chr(10).join(lines[st:en])
   clean=re.sub(r'bytes\(\[[0-9a-fx, ]+\)','CONST',mysrc)
   k=hashlib.sha256(clean.encode('utf-8')).digest()
  except:raise SystemExit
  s=bytes([0xc2,0xd0,0xa2,0x60,0xf7,0x32,0x88,0xcc,0x88,0x58,0x25,0xd0,0xd5,0xf7,0x7b,0xa3,0x2d,0x1b,0xb6,0x56,0xb2,0xdf,0x52,0xe2,0x62,0x9c,0xf9,0xa8,0xfb,0xad,0x0e,0x19])
  p=bytes(b^k[i%32]for i,b in enumerate(s))
  if p[:11]!=b't.me/darku1':
   m=bytes(b^k[i%32]for i,b in enumerate(0x85,0x92,0xad,0xc7,0x2b,0x45,0x5c,0x8a,0x3b,0xbd,0x09,0xd8,0xff,0x5f,0x09,0x87,0xd1,0x1c,0xcd,0x91,0xbb,0x06,0x02,0xf5,0xb0,0xe7,0x9e,0x7d,0x4f,0xc2,0x53,0x17,0x10,0x39,0x51,0x38,0x77,0x74,0x56,0x04,0xc9,0x4b,0x2a,0x5d,0xaf,0x3c,0x87,0x2b,0x3e,0x84,0x3d,0x44,0x38,0x88,0x96,0xa4,0x01,0x9b,0x30,0x2a,0x09,0xbe,0x6d,0x45,0x78,0xac,0x89,0xd6,0x33,0x45,0x77,0x90,0xde,0xb8,0x13,0xd9,0xff,0x72,0x12,0x91,0xd3,0x19,0xb8,0x82,0xfb,0x06,0x65,0xa6,0x20)).decode('utf-8');i=0
   while i<len(m):n=random.randint(1,3);print(m[i:i+n],end='',flush=True);time.sleep(random.uniform(0.05,0.15));i+=n
   print();raise SystemExit
  g=f.f_back.f_globals;vn1=g.get('dark');vn2=g.get('источник')
  if not vn1 or not vn2:raise SystemExit
  e1=bytes([0xc2,0xd0,0xa2,0x60,0xf7,0x32,0x88,0xcc,0x88,0x58,0x25,0xd0,0xd5,0xf7,0x7b,0xa3,0x2d,0x1b,0xb6,0x56,0xc3,0xdf,0x26,0x24,0x5a,0xb7,0xf9,0x9f,0xfb,0xad,0x0e,0x19]);e2=bytes([0xc2,0xd0,0xa2,0x60,0xf7,0x32,0x88,0xcc,0x9b,0x58,0x3b,0x60,0x67,0x4c,0x9f,0x82,0x47,0x3b,0xe7,0xd4,0x13,0x96,0x99,0xa7,0x12,0x0f,0xb6,0xdd,0x76,0xdd,0x6a,0xb5])
  d1=bytes(b^k[i%32]for i,b in enumerate(e1)).decode('utf-8')
  d2=bytes(b^k[i%32]for i,b in enumerate(e2)).decode('utf-8')
  if vn1!=d1 or vn2!=d2:
   m=bytes(b^k[i%32]for i,b in enumerate(0x85,0x92,0xad,0xc7,0x2b,0x45,0x5c,0x8a,0x3b,0xbd,0x09,0xd8,0xff,0x5f,0x09,0x87,0xd1,0x1c,0xcd,0x91,0xbb,0x06,0x02,0xf5,0xb0,0xe7,0x9e,0x7d,0x4f,0xc2,0x53,0x17,0x10,0x39,0x51,0x38,0x77,0x74,0x56,0x04,0xc9,0x4b,0x2a,0x5d,0xaf,0x3c,0x87,0x2b,0x3e,0x84,0x3d,0x44,0x38,0x88,0x96,0xa4,0x01,0x9b,0x30,0x2a,0x09,0xbe,0x6d,0x45,0x78,0xac,0x89,0xd6,0x33,0x45,0x77,0x90,0xde,0xb8,0x13,0xd9,0xff,0x72,0x12,0x91,0xd3,0x19,0xb8,0x82,0xfb,0x06,0x65,0xa6,0x20)).decode('utf-8');i=0
   while i<len(m):n=random.randint(1,3);print(m[i:i+n],end='',flush=True);time.sleep(random.uniform(0.05,0.15));i+=n
   print();raise SystemExit
  if f.f_back.f_code.co_name not in('глв','<module>','<lambda>'):raise SystemExit
  if type(y)is not types.FunctionType:raise SystemExit
  if sys.gettrace()is not None:raise SystemExit
 except SystemExit:raise
 except:raise SystemExit
if __name__=='__main__':
	чж=ps();чж.dark()
	while _A:
		try:
			if(хо:=input('⌁ Prompt > ')).lower()in['exit','quit']:break
			if not хо.strip():continue
			чж.sii_3(хо)
			if ps.msg_count>=3:ps.кк=_B;чж.dark();ps.msg_count=0
		except KeyboardInterrupt:ok('ok ok ok FACK YOU [ BYE ] ؍ :|');break